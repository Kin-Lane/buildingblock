#!/usr/bin/env python
"""Add all of the modules in the current directory to __all__"""
import os

# import models into package

from .models.buildingblock import Buildingblock

from .models.log import Log

from .models.tool import Tool

from .models.url import Url

from .models.image import Image

from .models.organization import Organization

from .models.tag import Tag

from .models.category import Category


# import apis into package

from .tags_api import TagsApi

from .logs_api import LogsApi

from .building_block_api import BuildingBlockApi

from .organizations_api import OrganizationsApi

from .ur_ls_api import URLsApi

from .images_api import ImagesApi

from .tools_api import ToolsApi

from .categories_api import CategoriesApi


# import ApiClient
from .swagger import ApiClient

__all__ = []

for module in os.listdir(os.path.dirname(__file__)):
  if module != '__init__.py' and module[-3:] == '.py':
    __all__.append(module[:-3])

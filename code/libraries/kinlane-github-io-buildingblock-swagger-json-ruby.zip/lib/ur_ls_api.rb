require "uri"

class URLsApi
  basePath = "https://buildingblock.api.kinlane.com/"
  # apiInvoker = APIInvoker

  # retrieve building block url
  # retrieve building block url
  # @param building_block_id id for building block
  # @param appid your appid for accessing the building block
  # @param appkey your appkey for accessing the building block
  # @param [Hash] opts the optional parameters
  # @return array[url]
  def self.getbuildingblock_ur_ls(building_block_id, appid, appkey, opts = {})
    # verify existence of params
    raise "building_block_id is required" if building_block_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/buildingblocks/{building_block_id}/urls/".sub('{format}','json').sub('{' + 'building_block_id' + '}', building_block_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| url.new(response) }
  end

  # add buildingblock URL
  # add buildingblock URL
  # @param building_block_id id for the building block
  # @param appid your appid for accessing the building block
  # @param appkey your appkey for accessing the building block
  # @param type type of url
  # @param url the url
  # @param name a name for the url
  # @param [Hash] opts the optional parameters
  # @return array[url]
  def self.add_building_block_url(building_block_id, appid, appkey, type, url, name, opts = {})
    # verify existence of params
    raise "building_block_id is required" if building_block_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "type is required" if type.nil?
    raise "url is required" if url.nil?
    raise "name is required" if name.nil?

    # resource path
    path = "/buildingblocks/{building_block_id}/urls/".sub('{format}','json').sub('{' + 'building_block_id' + '}', building_block_id.to_s)

    # query parameters
    query_params = {}

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}
    form_params["appid"] = appid
    form_params["appkey"] = appkey
    form_params["type"] = type
    form_params["url"] = url
    form_params["name"] = name

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:POST, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| url.new(response) }
  end

  # delete a building block url
  # delete a building block url
  # @param building_block_id id for the building block
  # @param appid your appid for accessing the building block
  # @param appkey your appkey for accessing the building block
  # @param url_id id for the url
  # @param [Hash] opts the optional parameters
  # @return array[url]
  def self.delete_building_block_url(building_block_id, appid, appkey, url_id, opts = {})
    # verify existence of params
    raise "building_block_id is required" if building_block_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "url_id is required" if url_id.nil?

    # resource path
    path = "/buildingblocks/{building_block_id}/urls/{url_id}".sub('{format}','json').sub('{' + 'building_block_id' + '}', building_block_id.to_s).sub('{' + 'url_id' + '}', url_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:DELETE, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| url.new(response) }
  end
end

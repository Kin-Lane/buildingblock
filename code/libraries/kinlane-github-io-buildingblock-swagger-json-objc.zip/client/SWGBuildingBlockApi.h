#import <Foundation/Foundation.h>
#import "SWGBuildingblock.h"
#import "SWGObject.h"


@interface SWGBuildingBlockApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGBuildingBlockApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 all building blocks
 all building blocks

 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 @param query a text query to search across building block
 @param page which page of results to show
 @param count how many to show on page
 @param sort which field to sort by
 

 return type: NSArray<SWGBuildingblock>*
 */
-(NSNumber*) getBuildingBlocksWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
     query:(NSString*) query 
     page:(NSString*) page 
     count:(NSString*) count 
     sort:(NSString*) sort 
    
    completionHandler: (void (^)(NSArray<SWGBuildingblock>* output, NSError* error))completionBlock;
    


/**

 add a building block post
 add a building block post

 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 @param building_block_category_id the category for the building block
 @param name name of the building block
 @param about details about the building block
 @param sort_order sort_order for the building block
 

 return type: NSArray<SWGBuildingblock>*
 */
-(NSNumber*) addBuildingBlockWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
     building_block_category_id:(NSString*) building_block_category_id 
     name:(NSString*) name 
     about:(NSString*) about 
     sort_order:(NSNumber*) sort_order 
    
    completionHandler: (void (^)(NSArray<SWGBuildingblock>* output, NSError* error))completionBlock;
    


/**

 building blocks by category
 building blocks by category

 @param category the building block category to filter by
 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 

 return type: NSArray<SWGBuildingblock>*
 */
-(NSNumber*) getBuildingBlocksByCategoryWithCompletionBlock :(NSString*) category 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGBuildingblock>* output, NSError* error))completionBlock;
    


/**

 building blocks by type
 building blocks by type

 @param type the building block type to filter by
 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 

 return type: NSArray<SWGBuildingblock>*
 */
-(NSNumber*) getBuildingBlocksByTypeWithCompletionBlock :(NSString*) type 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGBuildingblock>* output, NSError* error))completionBlock;
    


/**

 Retrieve a buildingblock using its slug
 Returns the building block detail

 @param building_block_id the unique id for buildingblock entry
 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 

 return type: NSArray<SWGBuildingblock>*
 */
-(NSNumber*) getBuildingBlockWithCompletionBlock :(NSString*) building_block_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGBuildingblock>* output, NSError* error))completionBlock;
    


/**

 update building block
 update building block

 @param building_block_id the unique id for buildingblock entry
 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 @param building_block_category_id the category for the building block
 @param name name of the building block
 @param about details about the building block
 @param sort_order sort_order for the building block
 

 return type: NSArray<SWGBuildingblock>*
 */
-(NSNumber*) updateBuildingBlockWithCompletionBlock :(NSString*) building_block_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     building_block_category_id:(NSString*) building_block_category_id 
     name:(NSString*) name 
     about:(NSString*) about 
     sort_order:(NSNumber*) sort_order 
    
    completionHandler: (void (^)(NSArray<SWGBuildingblock>* output, NSError* error))completionBlock;
    


/**

 delete building block
 delete building block

 @param building_block_id the unique id for buildingblock entry
 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 

 return type: NSArray<SWGBuildingblock>*
 */
-(NSNumber*) deleteBuildingBlockWithCompletionBlock :(NSString*) building_block_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGBuildingblock>* output, NSError* error))completionBlock;
    



@end
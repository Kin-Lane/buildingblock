using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace io.swagger.Model {
  public class Organization {
    

    /* name of the organization */
    
    public string Name { get; set; }

    

    /* details for the organization */
    
    public string Details { get; set; }

    

    /* summary of the organization */
    
    public string Summary { get; set; }

    

    /* date the organization was posted */
    
    public string PostDate { get; set; }

    

    /* primary URL for the organization */
    
    public string Url { get; set; }

    

    /* primary phone for the organization */
    
    public string Phone { get; set; }

    

    /* primary email for the organization */
    
    public string Email { get; set; }

    

    /* primary address for the organizaiton */
    
    public string Address { get; set; }

    

    /* primary city for the organizaiton */
    
    public string City { get; set; }

    

    /* primary state for the organizaiton */
    
    public string State { get; set; }

    

    /* primary postal code for the organizaiton */
    
    public string PostalCode { get; set; }

    

    /* primary country for the organizaiton */
    
    public string Country { get; set; }

    

    /* rank for the organizaiton */
    
    public string Rank { get; set; }

    

    /* primary location for the organizaiton */
    
    public string Location { get; set; }

    

    /* primary photo for the organizaiton */
    
    public string Photo { get; set; }

    

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Organization {\n");
      
      sb.Append("  Name: ").Append(Name).Append("\n");
      
      sb.Append("  Details: ").Append(Details).Append("\n");
      
      sb.Append("  Summary: ").Append(Summary).Append("\n");
      
      sb.Append("  PostDate: ").Append(PostDate).Append("\n");
      
      sb.Append("  Url: ").Append(Url).Append("\n");
      
      sb.Append("  Phone: ").Append(Phone).Append("\n");
      
      sb.Append("  Email: ").Append(Email).Append("\n");
      
      sb.Append("  Address: ").Append(Address).Append("\n");
      
      sb.Append("  City: ").Append(City).Append("\n");
      
      sb.Append("  State: ").Append(State).Append("\n");
      
      sb.Append("  PostalCode: ").Append(PostalCode).Append("\n");
      
      sb.Append("  Country: ").Append(Country).Append("\n");
      
      sb.Append("  Rank: ").Append(Rank).Append("\n");
      
      sb.Append("  Location: ").Append(Location).Append("\n");
      
      sb.Append("  Photo: ").Append(Photo).Append("\n");
      
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  
  
}
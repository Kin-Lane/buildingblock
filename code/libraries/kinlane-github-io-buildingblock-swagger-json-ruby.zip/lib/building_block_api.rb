require "uri"

class BuildingBlockApi
  basePath = "https://buildingblock.api.kinlane.com/"
  # apiInvoker = APIInvoker

  # all building blocks
  # all building blocks
  # @param appid your appid for accessing the building block
  # @param appkey your appkey for accessing the building block
  # @param [Hash] opts the optional parameters
  # @option opts [string] :query a text query to search across building block
  # @option opts [string] :page which page of results to show
  # @option opts [string] :count how many to show on page
  # @option opts [string] :sort which field to sort by
  # @return array[buildingblock]
  def self.get_building_blocks(appid, appkey, opts = {})
    # verify existence of params
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/buildingblocks/".sub('{format}','json')

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'query'] = opts[:'query'] if opts[:'query']
    query_params[:'page'] = opts[:'page'] if opts[:'page']
    query_params[:'count'] = opts[:'count'] if opts[:'count']
    query_params[:'sort'] = opts[:'sort'] if opts[:'sort']

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| buildingblock.new(response) }
  end

  # add a building block post
  # add a building block post
  # @param appid your appid for accessing the building block
  # @param appkey your appkey for accessing the building block
  # @param building_block_category_id the category for the building block
  # @param name name of the building block
  # @param [Hash] opts the optional parameters
  # @option opts [string] :about details about the building block
  # @option opts [int] :sort_order sort_order for the building block
  # @return array[buildingblock]
  def self.add_building_block(appid, appkey, building_block_category_id, name, opts = {})
    # verify existence of params
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "building_block_category_id is required" if building_block_category_id.nil?
    raise "name is required" if name.nil?

    # resource path
    path = "/buildingblocks/".sub('{format}','json')

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'building_block_category_id'] = building_block_category_id
    query_params[:'name'] = name
    query_params[:'about'] = opts[:'about'] if opts[:'about']
    query_params[:'sort_order'] = opts[:'sort_order'] if opts[:'sort_order']

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:POST, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| buildingblock.new(response) }
  end

  # building blocks by category
  # building blocks by category
  # @param category the building block category to filter by
  # @param appid your appid for accessing the building block
  # @param appkey your appkey for accessing the building block
  # @param [Hash] opts the optional parameters
  # @return array[buildingblock]
  def self.get_building_blocks_by_category(category, appid, appkey, opts = {})
    # verify existence of params
    raise "category is required" if category.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/buildingblocks/bycategory/{category}".sub('{format}','json').sub('{' + 'category' + '}', category.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| buildingblock.new(response) }
  end

  # building blocks by type
  # building blocks by type
  # @param type the building block type to filter by
  # @param appid your appid for accessing the building block
  # @param appkey your appkey for accessing the building block
  # @param [Hash] opts the optional parameters
  # @return array[buildingblock]
  def self.get_building_blocks_by_type(type, appid, appkey, opts = {})
    # verify existence of params
    raise "type is required" if type.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/buildingblocks/bytype/{type}".sub('{format}','json').sub('{' + 'type' + '}', type.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| buildingblock.new(response) }
  end

  # Retrieve a buildingblock using its slug
  # Returns the building block detail
  # @param building_block_id the unique id for buildingblock entry
  # @param appid your appid for accessing the building block
  # @param appkey your appkey for accessing the building block
  # @param [Hash] opts the optional parameters
  # @return array[buildingblock]
  def self.get_building_block(building_block_id, appid, appkey, opts = {})
    # verify existence of params
    raise "building_block_id is required" if building_block_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/buildingblocks/{building_block_id}/".sub('{format}','json').sub('{' + 'building_block_id' + '}', building_block_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| buildingblock.new(response) }
  end

  # update building block
  # update building block
  # @param building_block_id the unique id for buildingblock entry
  # @param appid your appid for accessing the building block
  # @param appkey your appkey for accessing the building block
  # @param building_block_category_id the category for the building block
  # @param [Hash] opts the optional parameters
  # @option opts [string] :name name of the building block
  # @option opts [string] :about details about the building block
  # @option opts [int] :sort_order sort_order for the building block
  # @return array[buildingblock]
  def self.update_building_block(building_block_id, appid, appkey, building_block_category_id, opts = {})
    # verify existence of params
    raise "building_block_id is required" if building_block_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "building_block_category_id is required" if building_block_category_id.nil?

    # resource path
    path = "/buildingblocks/{building_block_id}/".sub('{format}','json').sub('{' + 'building_block_id' + '}', building_block_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey
    query_params[:'building_block_category_id'] = building_block_category_id
    query_params[:'name'] = opts[:'name'] if opts[:'name']
    query_params[:'about'] = opts[:'about'] if opts[:'about']
    query_params[:'sort_order'] = opts[:'sort_order'] if opts[:'sort_order']

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:PUT, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| buildingblock.new(response) }
  end

  # delete building block
  # delete building block
  # @param building_block_id the unique id for buildingblock entry
  # @param appid your appid for accessing the building block
  # @param appkey your appkey for accessing the building block
  # @param [Hash] opts the optional parameters
  # @return array[buildingblock]
  def self.delete_building_block(building_block_id, appid, appkey, opts = {})
    # verify existence of params
    raise "building_block_id is required" if building_block_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/buildingblocks/{building_block_id}/".sub('{format}','json').sub('{' + 'building_block_id' + '}', building_block_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:DELETE, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| buildingblock.new(response) }
  end
end

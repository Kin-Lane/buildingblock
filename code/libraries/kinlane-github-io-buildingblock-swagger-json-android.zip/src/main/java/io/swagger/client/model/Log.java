package io.swagger.client.model;


import com.wordnik.swagger.annotations.*;
import com.fasterxml.jackson.annotation.JsonProperty;


@ApiModel(description = "")
public class Log  {
  
  private String type = null;
  private String note = null;
  private String details = null;
  private String logDate = null;

  
  /**
   * type of log
   **/
  @ApiModelProperty(value = "type of log")
  @JsonProperty("type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }

  
  /**
   * text of note
   **/
  @ApiModelProperty(value = "text of note")
  @JsonProperty("note")
  public String getNote() {
    return note;
  }
  public void setNote(String note) {
    this.note = note;
  }

  
  /**
   * details of log
   **/
  @ApiModelProperty(value = "details of log")
  @JsonProperty("details")
  public String getDetails() {
    return details;
  }
  public void setDetails(String details) {
    this.details = details;
  }

  
  /**
   * log date
   **/
  @ApiModelProperty(value = "log date")
  @JsonProperty("log_date")
  public String getLogDate() {
    return logDate;
  }
  public void setLogDate(String logDate) {
    this.logDate = logDate;
  }

  

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Log {\n");
    
    sb.append("  type: ").append(type).append("\n");
    sb.append("  note: ").append(note).append("\n");
    sb.append("  details: ").append(details).append("\n");
    sb.append("  logDate: ").append(logDate).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

#import <Foundation/Foundation.h>
#import "SWGTool.h"
#import "SWGObject.h"


@interface SWGToolsApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGToolsApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 retrieve building block tools
 retrieve building block tools

 @param building_block_id id for building block
 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 

 return type: NSArray<SWGTool>*
 */
-(NSNumber*) getBuildingBlockToolsWithCompletionBlock :(NSString*) building_block_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGTool>* output, NSError* error))completionBlock;
    


/**

 add tool to building block
 add tool to building block

 @param building_block_id id for the building block
 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 @param tool_id the unique tool id
 @param url url for the tool
 

 return type: NSArray<SWGTool>*
 */
-(NSNumber*) addBuildingBlockToolWithCompletionBlock :(NSString*) building_block_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     tool_id:(NSString*) tool_id 
     url:(NSString*) url 
    
    completionHandler: (void (^)(NSArray<SWGTool>* output, NSError* error))completionBlock;
    


/**

 delete a building block tool
 delete a building block tool

 @param building_block_id id for the building block
 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 @param tool_id tool to remove from building block
 

 return type: NSArray<SWGTool>*
 */
-(NSNumber*) getBuildingBlockToolWithCompletionBlock :(NSString*) building_block_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     tool_id:(NSString*) tool_id 
    
    completionHandler: (void (^)(NSArray<SWGTool>* output, NSError* error))completionBlock;
    



@end
#import <Foundation/Foundation.h>
#import "SWGObject.h"


@protocol SWGImage
@end
  
@interface SWGImage : SWGObject

/* name of the image [optional]
 */
@property(nonatomic) NSString* name;
/* path of the image [optional]
 */
@property(nonatomic) NSString* path;
/* type of image [optional]
 */
@property(nonatomic) NSString* type;

@end

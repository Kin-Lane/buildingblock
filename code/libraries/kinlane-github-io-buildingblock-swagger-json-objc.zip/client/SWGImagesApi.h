#import <Foundation/Foundation.h>
#import "SWGImage.h"
#import "SWGObject.h"


@interface SWGImagesApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGImagesApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 get building block images
 get building block images

 @param building_block_id id for building block
 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 

 return type: NSArray<SWGImage>*
 */
-(NSNumber*) getBuildingBlockImagesWithCompletionBlock :(NSString*) building_block_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGImage>* output, NSError* error))completionBlock;
    


/**

 add building block image
 add building block image

 @param building_block_id id for the building block
 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 @param path image path
 @param type image type
 @param name image name
 

 return type: NSArray<SWGImage>*
 */
-(NSNumber*) addBuildingBlockImageWithCompletionBlock :(NSString*) building_block_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     path:(NSString*) path 
     type:(NSString*) type 
     name:(NSString*) name 
    
    completionHandler: (void (^)(NSArray<SWGImage>* output, NSError* error))completionBlock;
    


/**

 delete a building block image
 delete a building block image

 @param building_block_id id for the building block
 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 @param image_id id for the image to remove from building block
 

 return type: NSArray<SWGImage>*
 */
-(NSNumber*) deleteBuildingBlockImageWithCompletionBlock :(NSString*) building_block_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     image_id:(NSString*) image_id 
    
    completionHandler: (void (^)(NSArray<SWGImage>* output, NSError* error))completionBlock;
    



@end
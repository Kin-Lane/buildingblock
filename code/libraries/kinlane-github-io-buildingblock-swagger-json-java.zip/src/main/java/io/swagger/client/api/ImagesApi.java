package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.ApiInvoker;

import io.swagger.client.model.*;

import java.util.*;

import io.swagger.client.model.Image;

import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.file.FileDataBodyPart;

import javax.ws.rs.core.MediaType;

import java.io.File;
import java.util.Map;
import java.util.HashMap;

public class ImagesApi {
  String basePath = "https://buildingblock.api.kinlane.com/";
  ApiInvoker apiInvoker = ApiInvoker.getInstance();

  public ApiInvoker getInvoker() {
    return apiInvoker;
  }

  public void setBasePath(String basePath) {
    this.basePath = basePath;
  }

  public String getBasePath() {
    return basePath;
  }

  
  /**
   * get building block images
   * get building block images
   * @param buildingBlockId id for building block
   * @param appid your appid for accessing the building block
   * @param appkey your appkey for accessing the building block
   * @return List<Image>
   */
  public List<Image> getBuildingBlockImages (String buildingBlockId, String appid, String appkey) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/buildingblocks/{building_block_id}/images/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "buildingBlockId" + "\\}", apiInvoker.escapeString(buildingBlockId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Image>) ApiInvoker.deserialize(response, "array", Image.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * add building block image
   * add building block image
   * @param buildingBlockId id for the building block
   * @param appid your appid for accessing the building block
   * @param appkey your appkey for accessing the building block
   * @param path image path
   * @param type image type
   * @param name image name
   * @return List<Image>
   */
  public List<Image> addBuildingBlockImage (String buildingBlockId, String appid, String appkey, String path, String type, String name) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/buildingblocks/{building_block_id}/images/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "buildingBlockId" + "\\}", apiInvoker.escapeString(buildingBlockId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      hasFields = true;
      mp.field("appid", ApiInvoker.parameterToString(appid), MediaType.MULTIPART_FORM_DATA_TYPE);
      
      hasFields = true;
      mp.field("appkey", ApiInvoker.parameterToString(appkey), MediaType.MULTIPART_FORM_DATA_TYPE);
      
      hasFields = true;
      mp.field("path", ApiInvoker.parameterToString(path), MediaType.MULTIPART_FORM_DATA_TYPE);
      
      hasFields = true;
      mp.field("type", ApiInvoker.parameterToString(type), MediaType.MULTIPART_FORM_DATA_TYPE);
      
      hasFields = true;
      mp.field("name", ApiInvoker.parameterToString(name), MediaType.MULTIPART_FORM_DATA_TYPE);
      
      if(hasFields)
        postBody = mp;
    }
    else {
      formParams.put("appid", ApiInvoker.parameterToString(appid));
      formParams.put("appkey", ApiInvoker.parameterToString(appkey));
      formParams.put("path", ApiInvoker.parameterToString(path));
      formParams.put("type", ApiInvoker.parameterToString(type));
      formParams.put("name", ApiInvoker.parameterToString(name));
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Image>) ApiInvoker.deserialize(response, "array", Image.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * delete a building block image
   * delete a building block image
   * @param buildingBlockId id for the building block
   * @param appid your appid for accessing the building block
   * @param appkey your appkey for accessing the building block
   * @param imageId id for the image to remove from building block
   * @return List<Image>
   */
  public List<Image> deleteBuildingBlockImage (String buildingBlockId, String appid, String appkey, String imageId) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/buildingblocks/{building_block_id}/images/{image_id}".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "buildingBlockId" + "\\}", apiInvoker.escapeString(buildingBlockId.toString()))
      .replaceAll("\\{" + "imageId" + "\\}", apiInvoker.escapeString(imageId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Image>) ApiInvoker.deserialize(response, "array", Image.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
}

package io.swagger.client.model;


import com.wordnik.swagger.annotations.*;
import com.fasterxml.jackson.annotation.JsonProperty;


@ApiModel(description = "")
public class Buildingblock  {
  
  private String name = null;
  private String about = null;

  
  /**
   * name of the building block
   **/
  @ApiModelProperty(value = "name of the building block")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  
  /**
   * about the building block
   **/
  @ApiModelProperty(value = "about the building block")
  @JsonProperty("about")
  public String getAbout() {
    return about;
  }
  public void setAbout(String about) {
    this.about = about;
  }

  

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Buildingblock {\n");
    
    sb.append("  name: ").append(name).append("\n");
    sb.append("  about: ").append(about).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

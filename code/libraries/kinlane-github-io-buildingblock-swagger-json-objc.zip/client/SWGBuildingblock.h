#import <Foundation/Foundation.h>
#import "SWGObject.h"


@protocol SWGBuildingblock
@end
  
@interface SWGBuildingblock : SWGObject

/* name of the building block [optional]
 */
@property(nonatomic) NSString* name;
/* about the building block [optional]
 */
@property(nonatomic) NSString* about;

@end

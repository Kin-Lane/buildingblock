#import <Foundation/Foundation.h>
#import "SWGOrganization.h"
#import "SWGObject.h"


@interface SWGOrganizationsApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGOrganizationsApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 retrieve building block companies
 retrieve building block companies

 @param building_block_id id for building block
 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 

 return type: NSArray<SWGOrganization>*
 */
-(NSNumber*) getBuildingBlockOrganizationsWithCompletionBlock :(NSString*) building_block_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGOrganization>* output, NSError* error))completionBlock;
    


/**

 add organization to building block
 add organization to building block

 @param building_block_id id for the building block
 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 @param organization_id the unique organization id
 @param url url for the tool
 

 return type: NSArray<SWGOrganization>*
 */
-(NSNumber*) addBuildingBlockOrganizationWithCompletionBlock :(NSString*) building_block_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     organization_id:(NSString*) organization_id 
     url:(NSString*) url 
    
    completionHandler: (void (^)(NSArray<SWGOrganization>* output, NSError* error))completionBlock;
    


/**

 delete a building block organization
 delete a building block organization

 @param building_block_id id for the building block
 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 @param organization_id organization to remove from building block
 

 return type: NSArray<SWGOrganization>*
 */
-(NSNumber*) getBuildingBlockOrganizationWithCompletionBlock :(NSString*) building_block_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     organization_id:(NSString*) organization_id 
    
    completionHandler: (void (^)(NSArray<SWGOrganization>* output, NSError* error))completionBlock;
    



@end
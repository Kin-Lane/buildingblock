require "uri"

class LogsApi
  basePath = "https://buildingblock.api.kinlane.com/"
  # apiInvoker = APIInvoker

  # get building block logs
  # get building block logs
  # @param building_block_id id for building block
  # @param appid your appid for accessing the building block
  # @param appkey your appkey for accessing the building block
  # @param [Hash] opts the optional parameters
  # @return array[log]
  def self.get_building_block_logs(building_block_id, appid, appkey, opts = {})
    # verify existence of params
    raise "building_block_id is required" if building_block_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/buildingblocks/{building_block_id}/logs/".sub('{format}','json').sub('{' + 'building_block_id' + '}', building_block_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| log.new(response) }
  end

  # add building block log
  # add building block log
  # @param building_block_id id for the building block
  # @param appid your appid for accessing the building block
  # @param appkey your appkey for accessing the building block
  # @param type type of log entry
  # @param details log details
  # @param [Hash] opts the optional parameters
  # @return array[log]
  def self.add_building_block_log(building_block_id, appid, appkey, type, details, opts = {})
    # verify existence of params
    raise "building_block_id is required" if building_block_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "type is required" if type.nil?
    raise "details is required" if details.nil?

    # resource path
    path = "/buildingblocks/{building_block_id}/logs/".sub('{format}','json').sub('{' + 'building_block_id' + '}', building_block_id.to_s)

    # query parameters
    query_params = {}

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}
    form_params["appid"] = appid
    form_params["appkey"] = appkey
    form_params["type"] = type
    form_params["details"] = details

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:POST, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| log.new(response) }
  end

  # delete a building block log
  # delete a building block log
  # @param building_block_id id for the building block
  # @param appid your appid for accessing the building block
  # @param appkey your appkey for accessing the building block
  # @param log_id id for the log
  # @param [Hash] opts the optional parameters
  # @return array[log]
  def self.delete_building_block_log(building_block_id, appid, appkey, log_id, opts = {})
    # verify existence of params
    raise "building_block_id is required" if building_block_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "log_id is required" if log_id.nil?

    # resource path
    path = "/buildingblocks/{building_block_id}/logs/{log_id}".sub('{format}','json').sub('{' + 'building_block_id' + '}', building_block_id.to_s).sub('{' + 'log_id' + '}', log_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:DELETE, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| log.new(response) }
  end
end

#import <Foundation/Foundation.h>
#import "SWGObject.h"


@protocol SWGUrl
@end
  
@interface SWGUrl : SWGObject

/* the type of url [optional]
 */
@property(nonatomic) NSString* type;
/* url for the url [optional]
 */
@property(nonatomic) NSString* url;
/* name of the url [optional]
 */
@property(nonatomic) NSString* name;

@end

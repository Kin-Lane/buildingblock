package io.swagger.client.model;


import com.wordnik.swagger.annotations.*;
import com.fasterxml.jackson.annotation.JsonProperty;


@ApiModel(description = "")
public class Category  {
  
  private String name = null;
  private String sortOrder = null;
  private String type = null;

  
  /**
   * name of category
   **/
  @ApiModelProperty(value = "name of category")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  
  /**
   * sort order for category
   **/
  @ApiModelProperty(value = "sort order for category")
  @JsonProperty("sort_order")
  public String getSortOrder() {
    return sortOrder;
  }
  public void setSortOrder(String sortOrder) {
    this.sortOrder = sortOrder;
  }

  
  /**
   * type of category
   **/
  @ApiModelProperty(value = "type of category")
  @JsonProperty("type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }

  

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Category {\n");
    
    sb.append("  name: ").append(name).append("\n");
    sb.append("  sortOrder: ").append(sortOrder).append("\n");
    sb.append("  type: ").append(type).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

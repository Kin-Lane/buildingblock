package io.swagger.client.model;


import com.wordnik.swagger.annotations.*;
import com.fasterxml.jackson.annotation.JsonProperty;


@ApiModel(description = "")
public class Tag  {
  
  private String tag = null;
  private Integer apiCount = null;

  
  /**
   * text tag
   **/
  @ApiModelProperty(value = "text tag")
  @JsonProperty("tag")
  public String getTag() {
    return tag;
  }
  public void setTag(String tag) {
    this.tag = tag;
  }

  
  /**
   * number of items api with tag
   **/
  @ApiModelProperty(value = "number of items api with tag")
  @JsonProperty("api_count")
  public Integer getApiCount() {
    return apiCount;
  }
  public void setApiCount(Integer apiCount) {
    this.apiCount = apiCount;
  }

  

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Tag {\n");
    
    sb.append("  tag: ").append(tag).append("\n");
    sb.append("  apiCount: ").append(apiCount).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

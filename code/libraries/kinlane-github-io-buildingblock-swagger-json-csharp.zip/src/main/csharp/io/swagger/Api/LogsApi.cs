using System;
using System.Collections.Generic;
using io.swagger.client;
using io.swagger.Model;

namespace io.swagger.Api {
  
  public class LogsApi {
    string basePath;
    private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

    public LogsApi(String basePath = "https://buildingblock.api.kinlane.com/")
    {
      this.basePath = basePath;
    }

    public ApiInvoker getInvoker() {
      return apiInvoker;
    }

    // Sets the endpoint base url for the services being accessed
    public void setBasePath(string basePath) {
      this.basePath = basePath;
    }

    // Gets the endpoint base url for the services being accessed
    public String getBasePath() {
      return basePath;
    }

    

    /// <summary>
    /// get building block logs get building block logs
    /// </summary>
    /// <param name="BuildingBlockId">id for building block</param>
     /// <param name="Appid">your appid for accessing the building block</param>
     /// <param name="Appkey">your appkey for accessing the building block</param>
    
    /// <returns></returns>
    public List<log>  GetBuildingBlockLogs (string BuildingBlockId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/buildingblocks/{building_block_id}/logs/".Replace("{format}","json").Replace("{" + "building_block_id" + "}", apiInvoker.ParameterToString(BuildingBlockId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<log>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<log>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<log>) ApiInvoker.deserialize(response, typeof(List<log>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// add building block log add building block log
    /// </summary>
    /// <param name="BuildingBlockId">id for the building block</param>
     /// <param name="Appid">your appid for accessing the building block</param>
     /// <param name="Appkey">your appkey for accessing the building block</param>
     /// <param name="Type">type of log entry</param>
     /// <param name="Details">log details</param>
    
    /// <returns></returns>
    public List<log>  AddBuildingBlockLog (string BuildingBlockId, string Appid, string Appkey, string Type, string Details) {
      // create path and map variables
      var path = "/buildingblocks/{building_block_id}/logs/".Replace("{format}","json").Replace("{" + "building_block_id" + "}", apiInvoker.ParameterToString(BuildingBlockId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      

      

      if (Appid != null){
        if(Appid is byte[]) {
          formParams.Add("appid", Appid);
        } else {
          formParams.Add("appid", apiInvoker.ParameterToString(Appid));
        }
      }
      if (Appkey != null){
        if(Appkey is byte[]) {
          formParams.Add("appkey", Appkey);
        } else {
          formParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
        }
      }
      if (Type != null){
        if(Type is byte[]) {
          formParams.Add("type", Type);
        } else {
          formParams.Add("type", apiInvoker.ParameterToString(Type));
        }
      }
      if (Details != null){
        if(Details is byte[]) {
          formParams.Add("details", Details);
        } else {
          formParams.Add("details", apiInvoker.ParameterToString(Details));
        }
      }
      

      try {
        if (typeof(List<log>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<log>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<log>) ApiInvoker.deserialize(response, typeof(List<log>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// delete a building block log delete a building block log
    /// </summary>
    /// <param name="BuildingBlockId">id for the building block</param>
     /// <param name="Appid">your appid for accessing the building block</param>
     /// <param name="Appkey">your appkey for accessing the building block</param>
     /// <param name="LogId">id for the log</param>
    
    /// <returns></returns>
    public List<log>  DeleteBuildingBlockLog (string BuildingBlockId, string Appid, string Appkey, string LogId) {
      // create path and map variables
      var path = "/buildingblocks/{building_block_id}/logs/{log_id}".Replace("{format}","json").Replace("{" + "building_block_id" + "}", apiInvoker.ParameterToString(BuildingBlockId)).Replace("{" + "log_id" + "}", apiInvoker.ParameterToString(LogId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<log>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<log>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<log>) ApiInvoker.deserialize(response, typeof(List<log>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    
  }
  
}

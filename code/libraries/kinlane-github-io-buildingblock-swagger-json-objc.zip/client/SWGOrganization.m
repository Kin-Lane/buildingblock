#import "SWGOrganization.h"

@implementation SWGOrganization
  
+ (JSONKeyMapper *)keyMapper
{
  return [[JSONKeyMapper alloc] initWithDictionary:@{ @"name": @"name", @"details": @"details", @"summary": @"summary", @"post_date": @"post_date", @"url": @"url", @"phone": @"phone", @"email": @"email", @"address": @"address", @"city": @"city", @"state": @"state", @"postal_code": @"postal_code", @"country": @"country", @"rank": @"rank", @"location": @"location", @"photo": @"photo" }];
}

+ (BOOL)propertyIsOptional:(NSString *)propertyName
{
  NSArray *optionalProperties = @[@"name", @"details", @"summary", @"post_date", @"url", @"phone", @"email", @"address", @"city", @"state", @"postal_code", @"country", @"rank", @"location", @"photo"];

  if ([optionalProperties containsObject:propertyName]) {
    return YES;
  }
  else {
    return NO;
  }
}

@end

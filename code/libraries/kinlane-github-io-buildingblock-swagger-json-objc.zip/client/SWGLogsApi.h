#import <Foundation/Foundation.h>
#import "SWGLog.h"
#import "SWGObject.h"


@interface SWGLogsApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGLogsApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 get building block logs
 get building block logs

 @param building_block_id id for building block
 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 

 return type: NSArray<SWGLog>*
 */
-(NSNumber*) getBuildingBlockLogsWithCompletionBlock :(NSString*) building_block_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGLog>* output, NSError* error))completionBlock;
    


/**

 add building block log
 add building block log

 @param building_block_id id for the building block
 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 @param type type of log entry
 @param details log details
 

 return type: NSArray<SWGLog>*
 */
-(NSNumber*) addBuildingBlockLogWithCompletionBlock :(NSString*) building_block_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     type:(NSString*) type 
     details:(NSString*) details 
    
    completionHandler: (void (^)(NSArray<SWGLog>* output, NSError* error))completionBlock;
    


/**

 delete a building block log
 delete a building block log

 @param building_block_id id for the building block
 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 @param log_id id for the log
 

 return type: NSArray<SWGLog>*
 */
-(NSNumber*) deleteBuildingBlockLogWithCompletionBlock :(NSString*) building_block_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     log_id:(NSString*) log_id 
    
    completionHandler: (void (^)(NSArray<SWGLog>* output, NSError* error))completionBlock;
    



@end
package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.ApiInvoker;

import io.swagger.client.model.*;

import java.util.*;

import io.swagger.client.model.Category;

import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.file.FileDataBodyPart;

import javax.ws.rs.core.MediaType;

import java.io.File;
import java.util.Map;
import java.util.HashMap;

public class CategoriesApi {
  String basePath = "https://buildingblock.api.kinlane.com/";
  ApiInvoker apiInvoker = ApiInvoker.getInstance();

  public ApiInvoker getInvoker() {
    return apiInvoker;
  }

  public void setBasePath(String basePath) {
    this.basePath = basePath;
  }

  public String getBasePath() {
    return basePath;
  }

  
  /**
   * retrieve building block categories
   * retrieve building block categories
   * @param appid your appid for accessing the building block
   * @param appkey your appkey for accessing the building block
   * @return List<Category>
   */
  public List<Category> getBuildingBlockCategories (String appid, String appkey) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/buildingblocks/categories/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Category>) ApiInvoker.deserialize(response, "array", Category.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * add building block category
   * add building block category
   * @param appid your appid for accessing the building block
   * @param appkey your appkey for accessing the building block
   * @param type type of url
   * @param url the url
   * @param name a name for the url
   * @return List<Category>
   */
  public List<Category> addBuildingBlockCategory (String appid, String appkey, String type, String url, String name) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/buildingblocks/categories/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      hasFields = true;
      mp.field("appid", ApiInvoker.parameterToString(appid), MediaType.MULTIPART_FORM_DATA_TYPE);
      
      hasFields = true;
      mp.field("appkey", ApiInvoker.parameterToString(appkey), MediaType.MULTIPART_FORM_DATA_TYPE);
      
      hasFields = true;
      mp.field("type", ApiInvoker.parameterToString(type), MediaType.MULTIPART_FORM_DATA_TYPE);
      
      hasFields = true;
      mp.field("url", ApiInvoker.parameterToString(url), MediaType.MULTIPART_FORM_DATA_TYPE);
      
      hasFields = true;
      mp.field("name", ApiInvoker.parameterToString(name), MediaType.MULTIPART_FORM_DATA_TYPE);
      
      if(hasFields)
        postBody = mp;
    }
    else {
      formParams.put("appid", ApiInvoker.parameterToString(appid));
      formParams.put("appkey", ApiInvoker.parameterToString(appkey));
      formParams.put("type", ApiInvoker.parameterToString(type));
      formParams.put("url", ApiInvoker.parameterToString(url));
      formParams.put("name", ApiInvoker.parameterToString(name));
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Category>) ApiInvoker.deserialize(response, "array", Category.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * delete a building block category
   * delete a building block category
   * @param categoryId id for the building block
   * @param appid your appid for accessing the building block
   * @param appkey your appkey for accessing the building block
   * @return List<Category>
   */
  public List<Category> deleteBuildingBlockCategory (String categoryId, String appid, String appkey) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/buildingblocks/categories/{category_id}".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "categoryId" + "\\}", apiInvoker.escapeString(categoryId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Category>) ApiInvoker.deserialize(response, "array", Category.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
}

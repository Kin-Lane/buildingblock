package io.swagger.client.model;


import com.wordnik.swagger.annotations.*;
import com.fasterxml.jackson.annotation.JsonProperty;


@ApiModel(description = "")
public class Organization  {
  
  private String name = null;
  private String details = null;
  private String summary = null;
  private String postDate = null;
  private String url = null;
  private String phone = null;
  private String email = null;
  private String address = null;
  private String city = null;
  private String state = null;
  private String postalCode = null;
  private String country = null;
  private String rank = null;
  private String location = null;
  private String photo = null;

  
  /**
   * name of the organization
   **/
  @ApiModelProperty(value = "name of the organization")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  
  /**
   * details for the organization
   **/
  @ApiModelProperty(value = "details for the organization")
  @JsonProperty("details")
  public String getDetails() {
    return details;
  }
  public void setDetails(String details) {
    this.details = details;
  }

  
  /**
   * summary of the organization
   **/
  @ApiModelProperty(value = "summary of the organization")
  @JsonProperty("summary")
  public String getSummary() {
    return summary;
  }
  public void setSummary(String summary) {
    this.summary = summary;
  }

  
  /**
   * date the organization was posted
   **/
  @ApiModelProperty(value = "date the organization was posted")
  @JsonProperty("post_date")
  public String getPostDate() {
    return postDate;
  }
  public void setPostDate(String postDate) {
    this.postDate = postDate;
  }

  
  /**
   * primary URL for the organization
   **/
  @ApiModelProperty(value = "primary URL for the organization")
  @JsonProperty("url")
  public String getUrl() {
    return url;
  }
  public void setUrl(String url) {
    this.url = url;
  }

  
  /**
   * primary phone for the organization
   **/
  @ApiModelProperty(value = "primary phone for the organization")
  @JsonProperty("phone")
  public String getPhone() {
    return phone;
  }
  public void setPhone(String phone) {
    this.phone = phone;
  }

  
  /**
   * primary email for the organization
   **/
  @ApiModelProperty(value = "primary email for the organization")
  @JsonProperty("email")
  public String getEmail() {
    return email;
  }
  public void setEmail(String email) {
    this.email = email;
  }

  
  /**
   * primary address for the organizaiton
   **/
  @ApiModelProperty(value = "primary address for the organizaiton")
  @JsonProperty("address")
  public String getAddress() {
    return address;
  }
  public void setAddress(String address) {
    this.address = address;
  }

  
  /**
   * primary city for the organizaiton
   **/
  @ApiModelProperty(value = "primary city for the organizaiton")
  @JsonProperty("city")
  public String getCity() {
    return city;
  }
  public void setCity(String city) {
    this.city = city;
  }

  
  /**
   * primary state for the organizaiton
   **/
  @ApiModelProperty(value = "primary state for the organizaiton")
  @JsonProperty("state")
  public String getState() {
    return state;
  }
  public void setState(String state) {
    this.state = state;
  }

  
  /**
   * primary postal code for the organizaiton
   **/
  @ApiModelProperty(value = "primary postal code for the organizaiton")
  @JsonProperty("postal_code")
  public String getPostalCode() {
    return postalCode;
  }
  public void setPostalCode(String postalCode) {
    this.postalCode = postalCode;
  }

  
  /**
   * primary country for the organizaiton
   **/
  @ApiModelProperty(value = "primary country for the organizaiton")
  @JsonProperty("country")
  public String getCountry() {
    return country;
  }
  public void setCountry(String country) {
    this.country = country;
  }

  
  /**
   * rank for the organizaiton
   **/
  @ApiModelProperty(value = "rank for the organizaiton")
  @JsonProperty("rank")
  public String getRank() {
    return rank;
  }
  public void setRank(String rank) {
    this.rank = rank;
  }

  
  /**
   * primary location for the organizaiton
   **/
  @ApiModelProperty(value = "primary location for the organizaiton")
  @JsonProperty("location")
  public String getLocation() {
    return location;
  }
  public void setLocation(String location) {
    this.location = location;
  }

  
  /**
   * primary photo for the organizaiton
   **/
  @ApiModelProperty(value = "primary photo for the organizaiton")
  @JsonProperty("photo")
  public String getPhoto() {
    return photo;
  }
  public void setPhoto(String photo) {
    this.photo = photo;
  }

  

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Organization {\n");
    
    sb.append("  name: ").append(name).append("\n");
    sb.append("  details: ").append(details).append("\n");
    sb.append("  summary: ").append(summary).append("\n");
    sb.append("  postDate: ").append(postDate).append("\n");
    sb.append("  url: ").append(url).append("\n");
    sb.append("  phone: ").append(phone).append("\n");
    sb.append("  email: ").append(email).append("\n");
    sb.append("  address: ").append(address).append("\n");
    sb.append("  city: ").append(city).append("\n");
    sb.append("  state: ").append(state).append("\n");
    sb.append("  postalCode: ").append(postalCode).append("\n");
    sb.append("  country: ").append(country).append("\n");
    sb.append("  rank: ").append(rank).append("\n");
    sb.append("  location: ").append(location).append("\n");
    sb.append("  photo: ").append(photo).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

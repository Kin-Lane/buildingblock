using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace io.swagger.Model {
  public class Tool {
    

    /* name of tool */
    
    public string Name { get; set; }

    

    /* details of the tool */
    
    public string Details { get; set; }

    

    /* date tool was posted */
    
    public string PostDate { get; set; }

    

    /* primary url for tool */
    
    public string Url { get; set; }

    

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Tool {\n");
      
      sb.Append("  Name: ").Append(Name).Append("\n");
      
      sb.Append("  Details: ").Append(Details).Append("\n");
      
      sb.Append("  PostDate: ").Append(PostDate).Append("\n");
      
      sb.Append("  Url: ").Append(Url).Append("\n");
      
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  
  
}
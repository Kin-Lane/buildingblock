using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace io.swagger.Model {
  public class Category {
    

    /* name of category */
    
    public string Name { get; set; }

    

    /* sort order for category */
    
    public string SortOrder { get; set; }

    

    /* type of category */
    
    public string Type { get; set; }

    

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Category {\n");
      
      sb.Append("  Name: ").Append(Name).Append("\n");
      
      sb.Append("  SortOrder: ").Append(SortOrder).Append("\n");
      
      sb.Append("  Type: ").Append(Type).Append("\n");
      
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  
  
}
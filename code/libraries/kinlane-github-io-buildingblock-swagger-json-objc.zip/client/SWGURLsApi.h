#import <Foundation/Foundation.h>
#import "SWGUrl.h"
#import "SWGObject.h"


@interface SWGURLsApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGURLsApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 retrieve building block url
 retrieve building block url

 @param building_block_id id for building block
 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 

 return type: NSArray<SWGUrl>*
 */
-(NSNumber*) getbuildingblockURLsWithCompletionBlock :(NSString*) building_block_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGUrl>* output, NSError* error))completionBlock;
    


/**

 add buildingblock URL
 add buildingblock URL

 @param building_block_id id for the building block
 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 @param type type of url
 @param url the url
 @param name a name for the url
 

 return type: NSArray<SWGUrl>*
 */
-(NSNumber*) addBuildingBlockURLWithCompletionBlock :(NSString*) building_block_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     type:(NSString*) type 
     url:(NSString*) url 
     name:(NSString*) name 
    
    completionHandler: (void (^)(NSArray<SWGUrl>* output, NSError* error))completionBlock;
    


/**

 delete a building block url
 delete a building block url

 @param building_block_id id for the building block
 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 @param url_id id for the url
 

 return type: NSArray<SWGUrl>*
 */
-(NSNumber*) deleteBuildingBlockURLWithCompletionBlock :(NSString*) building_block_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     url_id:(NSString*) url_id 
    
    completionHandler: (void (^)(NSArray<SWGUrl>* output, NSError* error))completionBlock;
    



@end
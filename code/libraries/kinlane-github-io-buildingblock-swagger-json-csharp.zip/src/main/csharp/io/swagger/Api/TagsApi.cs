using System;
using System.Collections.Generic;
using io.swagger.client;
using io.swagger.Model;

namespace io.swagger.Api {
  
  public class TagsApi {
    string basePath;
    private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

    public TagsApi(String basePath = "https://buildingblock.api.kinlane.com/")
    {
      this.basePath = basePath;
    }

    public ApiInvoker getInvoker() {
      return apiInvoker;
    }

    // Sets the endpoint base url for the services being accessed
    public void setBasePath(string basePath) {
      this.basePath = basePath;
    }

    // Gets the endpoint base url for the services being accessed
    public String getBasePath() {
      return basePath;
    }

    

    /// <summary>
    /// building block tags building block tags
    /// </summary>
    /// <param name="BuildingBlockId">id for building block</param>
     /// <param name="Appid">your appid for accessing the building block</param>
     /// <param name="Appkey">your appkey for accessing the building block</param>
    
    /// <returns></returns>
    public List<tag>  GetbuildingblockTags (string BuildingBlockId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/buildingblocks/{building_block_id}/tags/".Replace("{format}","json").Replace("{" + "building_block_id" + "}", apiInvoker.ParameterToString(BuildingBlockId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<tag>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<tag>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<tag>) ApiInvoker.deserialize(response, typeof(List<tag>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// add tag to building block add tag to building block
    /// </summary>
    /// <param name="BuildingBlockId">id for the building block</param>
     /// <param name="Appid">your appid for accessing the building block</param>
     /// <param name="Appkey">your appkey for accessing the building block</param>
     /// <param name="Tag">tag name</param>
    
    /// <returns></returns>
    public List<tag>  AddBuildingBlockTag (string BuildingBlockId, string Appid, string Appkey, string Tag) {
      // create path and map variables
      var path = "/buildingblocks/{building_block_id}/tags/".Replace("{format}","json").Replace("{" + "building_block_id" + "}", apiInvoker.ParameterToString(BuildingBlockId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (Tag != null){
        queryParams.Add("tag", apiInvoker.ParameterToString(Tag));
      }
      

      

      

      try {
        if (typeof(List<tag>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<tag>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<tag>) ApiInvoker.deserialize(response, typeof(List<tag>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// delete buildingblock tag delete buildingblock tag
    /// </summary>
    /// <param name="BuildingBlockId">id for the building block</param>
     /// <param name="Appid">your appid for accessing the building block</param>
     /// <param name="Appkey">your appkey for accessing the building block</param>
     /// <param name="Tag">tag to remove from building block</param>
    
    /// <returns></returns>
    public List<tag>  DeletebuildingblockTag (string BuildingBlockId, string Appid, string Appkey, string Tag) {
      // create path and map variables
      var path = "/buildingblocks/{building_block_id}/tags/{tag}".Replace("{format}","json").Replace("{" + "building_block_id" + "}", apiInvoker.ParameterToString(BuildingBlockId)).Replace("{" + "tag" + "}", apiInvoker.ParameterToString(Tag));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<tag>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<tag>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<tag>) ApiInvoker.deserialize(response, typeof(List<tag>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    
  }
  
}

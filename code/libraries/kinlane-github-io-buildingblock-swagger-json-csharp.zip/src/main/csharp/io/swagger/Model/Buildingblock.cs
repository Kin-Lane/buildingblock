using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

namespace io.swagger.Model {
  public class Buildingblock {
    

    /* name of the building block */
    
    public string Name { get; set; }

    

    /* about the building block */
    
    public string About { get; set; }

    

    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Buildingblock {\n");
      
      sb.Append("  Name: ").Append(Name).Append("\n");
      
      sb.Append("  About: ").Append(About).Append("\n");
      
      sb.Append("}\n");
      return sb.ToString();
    }
  }
  
  
}
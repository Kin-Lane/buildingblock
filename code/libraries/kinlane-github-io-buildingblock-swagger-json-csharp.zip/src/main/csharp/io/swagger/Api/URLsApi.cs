using System;
using System.Collections.Generic;
using io.swagger.client;
using io.swagger.Model;

namespace io.swagger.Api {
  
  public class URLsApi {
    string basePath;
    private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

    public URLsApi(String basePath = "https://buildingblock.api.kinlane.com/")
    {
      this.basePath = basePath;
    }

    public ApiInvoker getInvoker() {
      return apiInvoker;
    }

    // Sets the endpoint base url for the services being accessed
    public void setBasePath(string basePath) {
      this.basePath = basePath;
    }

    // Gets the endpoint base url for the services being accessed
    public String getBasePath() {
      return basePath;
    }

    

    /// <summary>
    /// retrieve building block url retrieve building block url
    /// </summary>
    /// <param name="BuildingBlockId">id for building block</param>
     /// <param name="Appid">your appid for accessing the building block</param>
     /// <param name="Appkey">your appkey for accessing the building block</param>
    
    /// <returns></returns>
    public List<url>  GetbuildingblockURLs (string BuildingBlockId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/buildingblocks/{building_block_id}/urls/".Replace("{format}","json").Replace("{" + "building_block_id" + "}", apiInvoker.ParameterToString(BuildingBlockId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<url>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<url>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<url>) ApiInvoker.deserialize(response, typeof(List<url>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// add buildingblock URL add buildingblock URL
    /// </summary>
    /// <param name="BuildingBlockId">id for the building block</param>
     /// <param name="Appid">your appid for accessing the building block</param>
     /// <param name="Appkey">your appkey for accessing the building block</param>
     /// <param name="Type">type of url</param>
     /// <param name="Url">the url</param>
     /// <param name="Name">a name for the url</param>
    
    /// <returns></returns>
    public List<url>  AddBuildingBlockURL (string BuildingBlockId, string Appid, string Appkey, string Type, string Url, string Name) {
      // create path and map variables
      var path = "/buildingblocks/{building_block_id}/urls/".Replace("{format}","json").Replace("{" + "building_block_id" + "}", apiInvoker.ParameterToString(BuildingBlockId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      

      

      if (Appid != null){
        if(Appid is byte[]) {
          formParams.Add("appid", Appid);
        } else {
          formParams.Add("appid", apiInvoker.ParameterToString(Appid));
        }
      }
      if (Appkey != null){
        if(Appkey is byte[]) {
          formParams.Add("appkey", Appkey);
        } else {
          formParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
        }
      }
      if (Type != null){
        if(Type is byte[]) {
          formParams.Add("type", Type);
        } else {
          formParams.Add("type", apiInvoker.ParameterToString(Type));
        }
      }
      if (Url != null){
        if(Url is byte[]) {
          formParams.Add("url", Url);
        } else {
          formParams.Add("url", apiInvoker.ParameterToString(Url));
        }
      }
      if (Name != null){
        if(Name is byte[]) {
          formParams.Add("name", Name);
        } else {
          formParams.Add("name", apiInvoker.ParameterToString(Name));
        }
      }
      

      try {
        if (typeof(List<url>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<url>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<url>) ApiInvoker.deserialize(response, typeof(List<url>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// delete a building block url delete a building block url
    /// </summary>
    /// <param name="BuildingBlockId">id for the building block</param>
     /// <param name="Appid">your appid for accessing the building block</param>
     /// <param name="Appkey">your appkey for accessing the building block</param>
     /// <param name="UrlId">id for the url</param>
    
    /// <returns></returns>
    public List<url>  DeleteBuildingBlockURL (string BuildingBlockId, string Appid, string Appkey, string UrlId) {
      // create path and map variables
      var path = "/buildingblocks/{building_block_id}/urls/{url_id}".Replace("{format}","json").Replace("{" + "building_block_id" + "}", apiInvoker.ParameterToString(BuildingBlockId)).Replace("{" + "url_id" + "}", apiInvoker.ParameterToString(UrlId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<url>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<url>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<url>) ApiInvoker.deserialize(response, typeof(List<url>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    
  }
  
}

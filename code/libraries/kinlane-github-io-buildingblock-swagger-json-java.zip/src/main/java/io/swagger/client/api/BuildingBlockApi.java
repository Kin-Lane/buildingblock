package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.ApiInvoker;

import io.swagger.client.model.*;

import java.util.*;

import io.swagger.client.model.Buildingblock;

import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.file.FileDataBodyPart;

import javax.ws.rs.core.MediaType;

import java.io.File;
import java.util.Map;
import java.util.HashMap;

public class BuildingBlockApi {
  String basePath = "https://buildingblock.api.kinlane.com/";
  ApiInvoker apiInvoker = ApiInvoker.getInstance();

  public ApiInvoker getInvoker() {
    return apiInvoker;
  }

  public void setBasePath(String basePath) {
    this.basePath = basePath;
  }

  public String getBasePath() {
    return basePath;
  }

  
  /**
   * all building blocks
   * all building blocks
   * @param appid your appid for accessing the building block
   * @param appkey your appkey for accessing the building block
   * @param query a text query to search across building block
   * @param page which page of results to show
   * @param count how many to show on page
   * @param sort which field to sort by
   * @return List<Buildingblock>
   */
  public List<Buildingblock> getBuildingBlocks (String appid, String appkey, String query, String page, String count, String sort) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/buildingblocks/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (query != null)
      queryParams.put("query", ApiInvoker.parameterToString(query));
    if (page != null)
      queryParams.put("page", ApiInvoker.parameterToString(page));
    if (count != null)
      queryParams.put("count", ApiInvoker.parameterToString(count));
    if (sort != null)
      queryParams.put("sort", ApiInvoker.parameterToString(sort));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Buildingblock>) ApiInvoker.deserialize(response, "array", Buildingblock.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * add a building block post
   * add a building block post
   * @param appid your appid for accessing the building block
   * @param appkey your appkey for accessing the building block
   * @param buildingBlockCategoryId the category for the building block
   * @param name name of the building block
   * @param about details about the building block
   * @param sortOrder sort_order for the building block
   * @return List<Buildingblock>
   */
  public List<Buildingblock> addBuildingBlock (String appid, String appkey, String buildingBlockCategoryId, String name, String about, Integer sortOrder) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/buildingblocks/".replaceAll("\\{format\\}","json");

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (buildingBlockCategoryId != null)
      queryParams.put("building_block_category_id", ApiInvoker.parameterToString(buildingBlockCategoryId));
    if (name != null)
      queryParams.put("name", ApiInvoker.parameterToString(name));
    if (about != null)
      queryParams.put("about", ApiInvoker.parameterToString(about));
    if (sortOrder != null)
      queryParams.put("sort_order", ApiInvoker.parameterToString(sortOrder));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Buildingblock>) ApiInvoker.deserialize(response, "array", Buildingblock.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * building blocks by category
   * building blocks by category
   * @param category the building block category to filter by
   * @param appid your appid for accessing the building block
   * @param appkey your appkey for accessing the building block
   * @return List<Buildingblock>
   */
  public List<Buildingblock> getBuildingBlocksByCategory (String category, String appid, String appkey) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/buildingblocks/bycategory/{category}".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "category" + "\\}", apiInvoker.escapeString(category.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Buildingblock>) ApiInvoker.deserialize(response, "array", Buildingblock.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * building blocks by type
   * building blocks by type
   * @param type the building block type to filter by
   * @param appid your appid for accessing the building block
   * @param appkey your appkey for accessing the building block
   * @return List<Buildingblock>
   */
  public List<Buildingblock> getBuildingBlocksByType (String type, String appid, String appkey) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/buildingblocks/bytype/{type}".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "type" + "\\}", apiInvoker.escapeString(type.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Buildingblock>) ApiInvoker.deserialize(response, "array", Buildingblock.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * Retrieve a buildingblock using its slug
   * Returns the building block detail
   * @param buildingBlockId the unique id for buildingblock entry
   * @param appid your appid for accessing the building block
   * @param appkey your appkey for accessing the building block
   * @return List<Buildingblock>
   */
  public List<Buildingblock> getBuildingBlock (String buildingBlockId, String appid, String appkey) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/buildingblocks/{building_block_id}/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "buildingBlockId" + "\\}", apiInvoker.escapeString(buildingBlockId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Buildingblock>) ApiInvoker.deserialize(response, "array", Buildingblock.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * update building block
   * update building block
   * @param buildingBlockId the unique id for buildingblock entry
   * @param appid your appid for accessing the building block
   * @param appkey your appkey for accessing the building block
   * @param buildingBlockCategoryId the category for the building block
   * @param name name of the building block
   * @param about details about the building block
   * @param sortOrder sort_order for the building block
   * @return List<Buildingblock>
   */
  public List<Buildingblock> updateBuildingBlock (String buildingBlockId, String appid, String appkey, String buildingBlockCategoryId, String name, String about, Integer sortOrder) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/buildingblocks/{building_block_id}/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "buildingBlockId" + "\\}", apiInvoker.escapeString(buildingBlockId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    if (buildingBlockCategoryId != null)
      queryParams.put("building_block_category_id", ApiInvoker.parameterToString(buildingBlockCategoryId));
    if (name != null)
      queryParams.put("name", ApiInvoker.parameterToString(name));
    if (about != null)
      queryParams.put("about", ApiInvoker.parameterToString(about));
    if (sortOrder != null)
      queryParams.put("sort_order", ApiInvoker.parameterToString(sortOrder));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "PUT", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Buildingblock>) ApiInvoker.deserialize(response, "array", Buildingblock.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * delete building block
   * delete building block
   * @param buildingBlockId the unique id for buildingblock entry
   * @param appid your appid for accessing the building block
   * @param appkey your appkey for accessing the building block
   * @return List<Buildingblock>
   */
  public List<Buildingblock> deleteBuildingBlock (String buildingBlockId, String appid, String appkey) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/buildingblocks/{building_block_id}/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "buildingBlockId" + "\\}", apiInvoker.escapeString(buildingBlockId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Buildingblock>) ApiInvoker.deserialize(response, "array", Buildingblock.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
}

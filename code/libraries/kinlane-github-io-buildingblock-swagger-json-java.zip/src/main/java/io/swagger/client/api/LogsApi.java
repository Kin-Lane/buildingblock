package io.swagger.client.api;

import io.swagger.client.ApiException;
import io.swagger.client.ApiInvoker;

import io.swagger.client.model.*;

import java.util.*;

import io.swagger.client.model.Log;

import com.sun.jersey.multipart.FormDataMultiPart;
import com.sun.jersey.multipart.file.FileDataBodyPart;

import javax.ws.rs.core.MediaType;

import java.io.File;
import java.util.Map;
import java.util.HashMap;

public class LogsApi {
  String basePath = "https://buildingblock.api.kinlane.com/";
  ApiInvoker apiInvoker = ApiInvoker.getInstance();

  public ApiInvoker getInvoker() {
    return apiInvoker;
  }

  public void setBasePath(String basePath) {
    this.basePath = basePath;
  }

  public String getBasePath() {
    return basePath;
  }

  
  /**
   * get building block logs
   * get building block logs
   * @param buildingBlockId id for building block
   * @param appid your appid for accessing the building block
   * @param appkey your appkey for accessing the building block
   * @return List<Log>
   */
  public List<Log> getBuildingBlockLogs (String buildingBlockId, String appid, String appkey) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/buildingblocks/{building_block_id}/logs/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "buildingBlockId" + "\\}", apiInvoker.escapeString(buildingBlockId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Log>) ApiInvoker.deserialize(response, "array", Log.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * add building block log
   * add building block log
   * @param buildingBlockId id for the building block
   * @param appid your appid for accessing the building block
   * @param appkey your appkey for accessing the building block
   * @param type type of log entry
   * @param details log details
   * @return List<Log>
   */
  public List<Log> addBuildingBlockLog (String buildingBlockId, String appid, String appkey, String type, String details) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/buildingblocks/{building_block_id}/logs/".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "buildingBlockId" + "\\}", apiInvoker.escapeString(buildingBlockId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      hasFields = true;
      mp.field("appid", ApiInvoker.parameterToString(appid), MediaType.MULTIPART_FORM_DATA_TYPE);
      
      hasFields = true;
      mp.field("appkey", ApiInvoker.parameterToString(appkey), MediaType.MULTIPART_FORM_DATA_TYPE);
      
      hasFields = true;
      mp.field("type", ApiInvoker.parameterToString(type), MediaType.MULTIPART_FORM_DATA_TYPE);
      
      hasFields = true;
      mp.field("details", ApiInvoker.parameterToString(details), MediaType.MULTIPART_FORM_DATA_TYPE);
      
      if(hasFields)
        postBody = mp;
    }
    else {
      formParams.put("appid", ApiInvoker.parameterToString(appid));
      formParams.put("appkey", ApiInvoker.parameterToString(appkey));
      formParams.put("type", ApiInvoker.parameterToString(type));
      formParams.put("details", ApiInvoker.parameterToString(details));
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Log>) ApiInvoker.deserialize(response, "array", Log.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
  /**
   * delete a building block log
   * delete a building block log
   * @param buildingBlockId id for the building block
   * @param appid your appid for accessing the building block
   * @param appkey your appkey for accessing the building block
   * @param logId id for the log
   * @return List<Log>
   */
  public List<Log> deleteBuildingBlockLog (String buildingBlockId, String appid, String appkey, String logId) throws ApiException {
    Object postBody = null;
    

    // create path and map variables
    String path = "/buildingblocks/{building_block_id}/logs/{log_id}".replaceAll("\\{format\\}","json")
      .replaceAll("\\{" + "buildingBlockId" + "\\}", apiInvoker.escapeString(buildingBlockId.toString()))
      .replaceAll("\\{" + "logId" + "\\}", apiInvoker.escapeString(logId.toString()));

    // query params
    Map<String, String> queryParams = new HashMap<String, String>();
    Map<String, String> headerParams = new HashMap<String, String>();
    Map<String, String> formParams = new HashMap<String, String>();

    if (appid != null)
      queryParams.put("appid", ApiInvoker.parameterToString(appid));
    if (appkey != null)
      queryParams.put("appkey", ApiInvoker.parameterToString(appkey));
    
    
    String[] contentTypes = {
      
    };

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";

    if(contentType.startsWith("multipart/form-data")) {
      boolean hasFields = false;
      FormDataMultiPart mp = new FormDataMultiPart();
      
      if(hasFields)
        postBody = mp;
    }
    else {
      
    }

    try {
      String response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, postBody, headerParams, formParams, contentType);
      if(response != null){
        return (List<Log>) ApiInvoker.deserialize(response, "array", Log.class);
      }
      else {
        return null;
      }
    } catch (ApiException ex) {
      throw ex;
    }
  }
  
}

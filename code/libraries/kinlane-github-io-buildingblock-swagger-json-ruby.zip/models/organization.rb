
class Organization
  attr_accessor :name, :details, :summary, :post_date, :url, :phone, :email, :address, :city, :state, :postal_code, :country, :rank, :location, :photo
  # :internal => :external
  def self.attribute_map
    {
      :name => :'name',
      :details => :'details',
      :summary => :'summary',
      :post_date => :'post_date',
      :url => :'url',
      :phone => :'phone',
      :email => :'email',
      :address => :'address',
      :city => :'city',
      :state => :'state',
      :postal_code => :'postal_code',
      :country => :'country',
      :rank => :'rank',
      :location => :'location',
      :photo => :'photo'
      
    }
  end

  def initialize(attributes = {})
    return if attributes.empty?
    # Morph attribute keys into undescored rubyish style
    
    if self.class.attribute_map[:"name"]
      @name = attributes["name"]
    end
    
    if self.class.attribute_map[:"details"]
      @details = attributes["details"]
    end
    
    if self.class.attribute_map[:"summary"]
      @summary = attributes["summary"]
    end
    
    if self.class.attribute_map[:"post_date"]
      @post_date = attributes["post_date"]
    end
    
    if self.class.attribute_map[:"url"]
      @url = attributes["url"]
    end
    
    if self.class.attribute_map[:"phone"]
      @phone = attributes["phone"]
    end
    
    if self.class.attribute_map[:"email"]
      @email = attributes["email"]
    end
    
    if self.class.attribute_map[:"address"]
      @address = attributes["address"]
    end
    
    if self.class.attribute_map[:"city"]
      @city = attributes["city"]
    end
    
    if self.class.attribute_map[:"state"]
      @state = attributes["state"]
    end
    
    if self.class.attribute_map[:"postal_code"]
      @postal_code = attributes["postal_code"]
    end
    
    if self.class.attribute_map[:"country"]
      @country = attributes["country"]
    end
    
    if self.class.attribute_map[:"rank"]
      @rank = attributes["rank"]
    end
    
    if self.class.attribute_map[:"location"]
      @location = attributes["location"]
    end
    
    if self.class.attribute_map[:"photo"]
      @photo = attributes["photo"]
    end
    
  end

  def to_body
    body = {}
    self.class.attribute_map.each_pair do |key, value|
      body[value] = self.send(key) unless self.send(key).nil?
    end
    body
  end
end

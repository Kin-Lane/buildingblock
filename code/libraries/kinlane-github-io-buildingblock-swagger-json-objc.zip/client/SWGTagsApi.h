#import <Foundation/Foundation.h>
#import "SWGTag.h"
#import "SWGObject.h"


@interface SWGTagsApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGTagsApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 building block tags
 building block tags

 @param building_block_id id for building block
 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 

 return type: NSArray<SWGTag>*
 */
-(NSNumber*) getbuildingblockTagsWithCompletionBlock :(NSString*) building_block_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGTag>* output, NSError* error))completionBlock;
    


/**

 add tag to building block
 add tag to building block

 @param building_block_id id for the building block
 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 @param tag tag name
 

 return type: NSArray<SWGTag>*
 */
-(NSNumber*) addBuildingBlockTagWithCompletionBlock :(NSString*) building_block_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     tag:(NSString*) tag 
    
    completionHandler: (void (^)(NSArray<SWGTag>* output, NSError* error))completionBlock;
    


/**

 delete buildingblock tag
 delete buildingblock tag

 @param building_block_id id for the building block
 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 @param tag tag to remove from building block
 

 return type: NSArray<SWGTag>*
 */
-(NSNumber*) deletebuildingblockTagWithCompletionBlock :(NSString*) building_block_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
     tag:(NSString*) tag 
    
    completionHandler: (void (^)(NSArray<SWGTag>* output, NSError* error))completionBlock;
    



@end
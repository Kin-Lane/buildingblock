package io.swagger.client.model;


import com.wordnik.swagger.annotations.*;
import com.fasterxml.jackson.annotation.JsonProperty;


@ApiModel(description = "")
public class Tool  {
  
  private String name = null;
  private String details = null;
  private String postDate = null;
  private String url = null;

  
  /**
   * name of tool
   **/
  @ApiModelProperty(value = "name of tool")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  
  /**
   * details of the tool
   **/
  @ApiModelProperty(value = "details of the tool")
  @JsonProperty("details")
  public String getDetails() {
    return details;
  }
  public void setDetails(String details) {
    this.details = details;
  }

  
  /**
   * date tool was posted
   **/
  @ApiModelProperty(value = "date tool was posted")
  @JsonProperty("post_date")
  public String getPostDate() {
    return postDate;
  }
  public void setPostDate(String postDate) {
    this.postDate = postDate;
  }

  
  /**
   * primary url for tool
   **/
  @ApiModelProperty(value = "primary url for tool")
  @JsonProperty("url")
  public String getUrl() {
    return url;
  }
  public void setUrl(String url) {
    this.url = url;
  }

  

  @Override
  public String toString()  {
    StringBuilder sb = new StringBuilder();
    sb.append("class Tool {\n");
    
    sb.append("  name: ").append(name).append("\n");
    sb.append("  details: ").append(details).append("\n");
    sb.append("  postDate: ").append(postDate).append("\n");
    sb.append("  url: ").append(url).append("\n");
    sb.append("}\n");
    return sb.toString();
  }
}

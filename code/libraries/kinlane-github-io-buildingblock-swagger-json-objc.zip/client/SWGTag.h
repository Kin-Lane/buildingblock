#import <Foundation/Foundation.h>
#import "SWGObject.h"


@protocol SWGTag
@end
  
@interface SWGTag : SWGObject

/* text tag [optional]
 */
@property(nonatomic) NSString* tag;
/* number of items api with tag [optional]
 */
@property(nonatomic) NSNumber* api_count;

@end

#import <Foundation/Foundation.h>
#import "SWGCategory.h"
#import "SWGObject.h"


@interface SWGCategoriesApi: NSObject

-(void) addHeader:(NSString*)value forKey:(NSString*)key;
-(unsigned long) requestQueueSize;
+(SWGCategoriesApi*) apiWithHeader:(NSString*)headerValue key:(NSString*)key;
+(void) setBasePath:(NSString*)basePath;
+(NSString*) getBasePath;
/**

 retrieve building block categories
 retrieve building block categories

 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 

 return type: NSArray<SWGCategory>*
 */
-(NSNumber*) getBuildingBlockCategoriesWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGCategory>* output, NSError* error))completionBlock;
    


/**

 add building block category
 add building block category

 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 @param type type of url
 @param url the url
 @param name a name for the url
 

 return type: NSArray<SWGCategory>*
 */
-(NSNumber*) addBuildingBlockCategoryWithCompletionBlock :(NSString*) appid 
     appkey:(NSString*) appkey 
     type:(NSString*) type 
     url:(NSString*) url 
     name:(NSString*) name 
    
    completionHandler: (void (^)(NSArray<SWGCategory>* output, NSError* error))completionBlock;
    


/**

 delete a building block category
 delete a building block category

 @param category_id id for the building block
 @param appid your appid for accessing the building block
 @param appkey your appkey for accessing the building block
 

 return type: NSArray<SWGCategory>*
 */
-(NSNumber*) deleteBuildingBlockCategoryWithCompletionBlock :(NSString*) category_id 
     appid:(NSString*) appid 
     appkey:(NSString*) appkey 
    
    completionHandler: (void (^)(NSArray<SWGCategory>* output, NSError* error))completionBlock;
    



@end
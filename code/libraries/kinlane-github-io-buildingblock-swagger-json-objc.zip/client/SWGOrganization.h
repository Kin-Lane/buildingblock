#import <Foundation/Foundation.h>
#import "SWGObject.h"


@protocol SWGOrganization
@end
  
@interface SWGOrganization : SWGObject

/* name of the organization [optional]
 */
@property(nonatomic) NSString* name;
/* details for the organization [optional]
 */
@property(nonatomic) NSString* details;
/* summary of the organization [optional]
 */
@property(nonatomic) NSString* summary;
/* date the organization was posted [optional]
 */
@property(nonatomic) NSString* post_date;
/* primary URL for the organization [optional]
 */
@property(nonatomic) NSString* url;
/* primary phone for the organization [optional]
 */
@property(nonatomic) NSString* phone;
/* primary email for the organization [optional]
 */
@property(nonatomic) NSString* email;
/* primary address for the organizaiton [optional]
 */
@property(nonatomic) NSString* address;
/* primary city for the organizaiton [optional]
 */
@property(nonatomic) NSString* city;
/* primary state for the organizaiton [optional]
 */
@property(nonatomic) NSString* state;
/* primary postal code for the organizaiton [optional]
 */
@property(nonatomic) NSString* postal_code;
/* primary country for the organizaiton [optional]
 */
@property(nonatomic) NSString* country;
/* rank for the organizaiton [optional]
 */
@property(nonatomic) NSString* rank;
/* primary location for the organizaiton [optional]
 */
@property(nonatomic) NSString* location;
/* primary photo for the organizaiton [optional]
 */
@property(nonatomic) NSString* photo;

@end

#import <Foundation/Foundation.h>
#import "SWGObject.h"


@protocol SWGCategory
@end
  
@interface SWGCategory : SWGObject

/* name of category [optional]
 */
@property(nonatomic) NSString* name;
/* sort order for category [optional]
 */
@property(nonatomic) NSString* sort_order;
/* type of category [optional]
 */
@property(nonatomic) NSString* type;

@end

import sys
from setuptools import setup, find_packages



# To install the library, open a Terminal shell, then run this
# file by typing:
#
# python setup.py install
#
# You need to have the setuptools module installed.
# Try reading the setuptools documentation:
# http://pypi.python.org/pypi/setuptools

REQUIRES = []

setup(
    name="SwaggerPetstore",
    version="v2",
    description="Building Block",
    author_email="",
    url="",
    keywords=["Swagger", "Building Block"],
    install_requires=REQUIRES,
    packages=find_packages(),
    include_package_data=True,
    long_description="""\
    This is an buildingblock for all my buildingblock entries. I use a single buildingblock system to manage all my sites. Based upon tagging, I then publish each post out to its respective Github Page based repo.
    """
)



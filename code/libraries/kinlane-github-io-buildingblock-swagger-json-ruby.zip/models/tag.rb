
class Tag
  attr_accessor :tag, :api_count
  # :internal => :external
  def self.attribute_map
    {
      :tag => :'tag',
      :api_count => :'api_count'
      
    }
  end

  def initialize(attributes = {})
    return if attributes.empty?
    # Morph attribute keys into undescored rubyish style
    
    if self.class.attribute_map[:"tag"]
      @tag = attributes["tag"]
    end
    
    if self.class.attribute_map[:"api_count"]
      @api_count = attributes["api_count"]
    end
    
  end

  def to_body
    body = {}
    self.class.attribute_map.each_pair do |key, value|
      body[value] = self.send(key) unless self.send(key).nil?
    end
    body
  end
end

#import <Foundation/Foundation.h>
#import "SWGObject.h"


@protocol SWGTool
@end
  
@interface SWGTool : SWGObject

/* name of tool [optional]
 */
@property(nonatomic) NSString* name;
/* details of the tool [optional]
 */
@property(nonatomic) NSString* details;
/* date tool was posted [optional]
 */
@property(nonatomic) NSString* post_date;
/* primary url for tool [optional]
 */
@property(nonatomic) NSString* url;

@end

#import <Foundation/Foundation.h>
#import "JSONModel.h"

@interface SWGObject : JSONModel
@end

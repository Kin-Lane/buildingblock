require "uri"

class ToolsApi
  basePath = "https://buildingblock.api.kinlane.com/"
  # apiInvoker = APIInvoker

  # retrieve building block tools
  # retrieve building block tools
  # @param building_block_id id for building block
  # @param appid your appid for accessing the building block
  # @param appkey your appkey for accessing the building block
  # @param [Hash] opts the optional parameters
  # @return array[tool]
  def self.get_building_block_tools(building_block_id, appid, appkey, opts = {})
    # verify existence of params
    raise "building_block_id is required" if building_block_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/buildingblocks/{building_block_id}/tools/".sub('{format}','json').sub('{' + 'building_block_id' + '}', building_block_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:GET, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| tool.new(response) }
  end

  # add tool to building block
  # add tool to building block
  # @param building_block_id id for the building block
  # @param appid your appid for accessing the building block
  # @param appkey your appkey for accessing the building block
  # @param [Hash] opts the optional parameters
  # @option opts [string] :tool_id the unique tool id
  # @option opts [string] :url url for the tool
  # @return array[tool]
  def self.add_building_block_tool(building_block_id, appid, appkey, opts = {})
    # verify existence of params
    raise "building_block_id is required" if building_block_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?

    # resource path
    path = "/buildingblocks/{building_block_id}/tools/".sub('{format}','json').sub('{' + 'building_block_id' + '}', building_block_id.to_s)

    # query parameters
    query_params = {}

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}
    form_params["appid"] = appid
    form_params["appkey"] = appkey
    form_params["tool_id"] = opts[:'tool_id'] if opts[:'tool_id']
    form_params["url"] = opts[:'url'] if opts[:'url']

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:POST, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| tool.new(response) }
  end

  # delete a building block tool
  # delete a building block tool
  # @param building_block_id id for the building block
  # @param appid your appid for accessing the building block
  # @param appkey your appkey for accessing the building block
  # @param tool_id tool to remove from building block
  # @param [Hash] opts the optional parameters
  # @return array[tool]
  def self.get_building_block_tool(building_block_id, appid, appkey, tool_id, opts = {})
    # verify existence of params
    raise "building_block_id is required" if building_block_id.nil?
    raise "appid is required" if appid.nil?
    raise "appkey is required" if appkey.nil?
    raise "tool_id is required" if tool_id.nil?

    # resource path
    path = "/buildingblocks/{building_block_id}/tools/{tool_id}".sub('{format}','json').sub('{' + 'building_block_id' + '}', building_block_id.to_s).sub('{' + 'tool_id' + '}', tool_id.to_s)

    # query parameters
    query_params = {}
    query_params[:'appid'] = appid
    query_params[:'appkey'] = appkey

    # header parameters
    header_params = {}

    _header_accept = ''
    header_params['Accept'] = _header_accept if _header_accept != ''

    _header_content_type = []
    header_params['Content-Type'] = _header_content_type.length > 0 ? _header_content_type[0] : 'application/json'

    # form parameters
    form_params = {}

    # http body (model)
    post_body = nil

    response = Swagger::Request.new(:DELETE, path, {:params => query_params, :headers => header_params, :form_params => form_params, :body => post_body}).make.body
    response.map {|response| tool.new(response) }
  end
end

using System;
using System.Collections.Generic;
using io.swagger.client;
using io.swagger.Model;

namespace io.swagger.Api {
  
  public class BuildingBlockApi {
    string basePath;
    private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

    public BuildingBlockApi(String basePath = "https://buildingblock.api.kinlane.com/")
    {
      this.basePath = basePath;
    }

    public ApiInvoker getInvoker() {
      return apiInvoker;
    }

    // Sets the endpoint base url for the services being accessed
    public void setBasePath(string basePath) {
      this.basePath = basePath;
    }

    // Gets the endpoint base url for the services being accessed
    public String getBasePath() {
      return basePath;
    }

    

    /// <summary>
    /// all building blocks all building blocks
    /// </summary>
    /// <param name="Appid">your appid for accessing the building block</param>
     /// <param name="Appkey">your appkey for accessing the building block</param>
     /// <param name="Query">a text query to search across building block</param>
     /// <param name="Page">which page of results to show</param>
     /// <param name="Count">how many to show on page</param>
     /// <param name="Sort">which field to sort by</param>
    
    /// <returns></returns>
    public List<buildingblock>  GetBuildingBlocks (string Appid, string Appkey, string Query, string Page, string Count, string Sort) {
      // create path and map variables
      var path = "/buildingblocks/".Replace("{format}","json");

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (Query != null){
        queryParams.Add("query", apiInvoker.ParameterToString(Query));
      }
      if (Page != null){
        queryParams.Add("page", apiInvoker.ParameterToString(Page));
      }
      if (Count != null){
        queryParams.Add("count", apiInvoker.ParameterToString(Count));
      }
      if (Sort != null){
        queryParams.Add("sort", apiInvoker.ParameterToString(Sort));
      }
      

      

      

      try {
        if (typeof(List<buildingblock>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<buildingblock>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<buildingblock>) ApiInvoker.deserialize(response, typeof(List<buildingblock>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// add a building block post add a building block post
    /// </summary>
    /// <param name="Appid">your appid for accessing the building block</param>
     /// <param name="Appkey">your appkey for accessing the building block</param>
     /// <param name="BuildingBlockCategoryId">the category for the building block</param>
     /// <param name="Name">name of the building block</param>
     /// <param name="About">details about the building block</param>
     /// <param name="SortOrder">sort_order for the building block</param>
    
    /// <returns></returns>
    public List<buildingblock>  AddBuildingBlock (string Appid, string Appkey, string BuildingBlockCategoryId, string Name, string About, int? SortOrder) {
      // create path and map variables
      var path = "/buildingblocks/".Replace("{format}","json");

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (BuildingBlockCategoryId != null){
        queryParams.Add("building_block_category_id", apiInvoker.ParameterToString(BuildingBlockCategoryId));
      }
      if (Name != null){
        queryParams.Add("name", apiInvoker.ParameterToString(Name));
      }
      if (About != null){
        queryParams.Add("about", apiInvoker.ParameterToString(About));
      }
      if (SortOrder != null){
        queryParams.Add("sort_order", apiInvoker.ParameterToString(SortOrder));
      }
      

      

      

      try {
        if (typeof(List<buildingblock>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<buildingblock>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<buildingblock>) ApiInvoker.deserialize(response, typeof(List<buildingblock>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// building blocks by category building blocks by category
    /// </summary>
    /// <param name="Category">the building block category to filter by</param>
     /// <param name="Appid">your appid for accessing the building block</param>
     /// <param name="Appkey">your appkey for accessing the building block</param>
    
    /// <returns></returns>
    public List<buildingblock>  GetBuildingBlocksByCategory (string Category, string Appid, string Appkey) {
      // create path and map variables
      var path = "/buildingblocks/bycategory/{category}".Replace("{format}","json").Replace("{" + "category" + "}", apiInvoker.ParameterToString(Category));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<buildingblock>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<buildingblock>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<buildingblock>) ApiInvoker.deserialize(response, typeof(List<buildingblock>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// building blocks by type building blocks by type
    /// </summary>
    /// <param name="Type">the building block type to filter by</param>
     /// <param name="Appid">your appid for accessing the building block</param>
     /// <param name="Appkey">your appkey for accessing the building block</param>
    
    /// <returns></returns>
    public List<buildingblock>  GetBuildingBlocksByType (string Type, string Appid, string Appkey) {
      // create path and map variables
      var path = "/buildingblocks/bytype/{type}".Replace("{format}","json").Replace("{" + "type" + "}", apiInvoker.ParameterToString(Type));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<buildingblock>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<buildingblock>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<buildingblock>) ApiInvoker.deserialize(response, typeof(List<buildingblock>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// Retrieve a buildingblock using its slug Returns the building block detail
    /// </summary>
    /// <param name="BuildingBlockId">the unique id for buildingblock entry</param>
     /// <param name="Appid">your appid for accessing the building block</param>
     /// <param name="Appkey">your appkey for accessing the building block</param>
    
    /// <returns></returns>
    public List<buildingblock>  GetBuildingBlock (string BuildingBlockId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/buildingblocks/{building_block_id}/".Replace("{format}","json").Replace("{" + "building_block_id" + "}", apiInvoker.ParameterToString(BuildingBlockId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<buildingblock>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<buildingblock>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<buildingblock>) ApiInvoker.deserialize(response, typeof(List<buildingblock>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// update building block update building block
    /// </summary>
    /// <param name="BuildingBlockId">the unique id for buildingblock entry</param>
     /// <param name="Appid">your appid for accessing the building block</param>
     /// <param name="Appkey">your appkey for accessing the building block</param>
     /// <param name="BuildingBlockCategoryId">the category for the building block</param>
     /// <param name="Name">name of the building block</param>
     /// <param name="About">details about the building block</param>
     /// <param name="SortOrder">sort_order for the building block</param>
    
    /// <returns></returns>
    public List<buildingblock>  UpdateBuildingBlock (string BuildingBlockId, string Appid, string Appkey, string BuildingBlockCategoryId, string Name, string About, int? SortOrder) {
      // create path and map variables
      var path = "/buildingblocks/{building_block_id}/".Replace("{format}","json").Replace("{" + "building_block_id" + "}", apiInvoker.ParameterToString(BuildingBlockId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      if (BuildingBlockCategoryId != null){
        queryParams.Add("building_block_category_id", apiInvoker.ParameterToString(BuildingBlockCategoryId));
      }
      if (Name != null){
        queryParams.Add("name", apiInvoker.ParameterToString(Name));
      }
      if (About != null){
        queryParams.Add("about", apiInvoker.ParameterToString(About));
      }
      if (SortOrder != null){
        queryParams.Add("sort_order", apiInvoker.ParameterToString(SortOrder));
      }
      

      

      

      try {
        if (typeof(List<buildingblock>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<buildingblock>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "PUT", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<buildingblock>) ApiInvoker.deserialize(response, typeof(List<buildingblock>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// delete building block delete building block
    /// </summary>
    /// <param name="BuildingBlockId">the unique id for buildingblock entry</param>
     /// <param name="Appid">your appid for accessing the building block</param>
     /// <param name="Appkey">your appkey for accessing the building block</param>
    
    /// <returns></returns>
    public List<buildingblock>  DeleteBuildingBlock (string BuildingBlockId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/buildingblocks/{building_block_id}/".Replace("{format}","json").Replace("{" + "building_block_id" + "}", apiInvoker.ParameterToString(BuildingBlockId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<buildingblock>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<buildingblock>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<buildingblock>) ApiInvoker.deserialize(response, typeof(List<buildingblock>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    
  }
  
}

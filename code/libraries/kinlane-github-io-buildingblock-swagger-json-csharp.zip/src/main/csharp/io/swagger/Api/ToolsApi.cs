using System;
using System.Collections.Generic;
using io.swagger.client;
using io.swagger.Model;

namespace io.swagger.Api {
  
  public class ToolsApi {
    string basePath;
    private readonly ApiInvoker apiInvoker = ApiInvoker.GetInstance();

    public ToolsApi(String basePath = "https://buildingblock.api.kinlane.com/")
    {
      this.basePath = basePath;
    }

    public ApiInvoker getInvoker() {
      return apiInvoker;
    }

    // Sets the endpoint base url for the services being accessed
    public void setBasePath(string basePath) {
      this.basePath = basePath;
    }

    // Gets the endpoint base url for the services being accessed
    public String getBasePath() {
      return basePath;
    }

    

    /// <summary>
    /// retrieve building block tools retrieve building block tools
    /// </summary>
    /// <param name="BuildingBlockId">id for building block</param>
     /// <param name="Appid">your appid for accessing the building block</param>
     /// <param name="Appkey">your appkey for accessing the building block</param>
    
    /// <returns></returns>
    public List<tool>  GetBuildingBlockTools (string BuildingBlockId, string Appid, string Appkey) {
      // create path and map variables
      var path = "/buildingblocks/{building_block_id}/tools/".Replace("{format}","json").Replace("{" + "building_block_id" + "}", apiInvoker.ParameterToString(BuildingBlockId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<tool>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<tool>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<tool>) ApiInvoker.deserialize(response, typeof(List<tool>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// add tool to building block add tool to building block
    /// </summary>
    /// <param name="BuildingBlockId">id for the building block</param>
     /// <param name="Appid">your appid for accessing the building block</param>
     /// <param name="Appkey">your appkey for accessing the building block</param>
     /// <param name="ToolId">the unique tool id</param>
     /// <param name="Url">url for the tool</param>
    
    /// <returns></returns>
    public List<tool>  AddBuildingBlockTool (string BuildingBlockId, string Appid, string Appkey, string ToolId, string Url) {
      // create path and map variables
      var path = "/buildingblocks/{building_block_id}/tools/".Replace("{format}","json").Replace("{" + "building_block_id" + "}", apiInvoker.ParameterToString(BuildingBlockId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      

      

      if (Appid != null){
        if(Appid is byte[]) {
          formParams.Add("appid", Appid);
        } else {
          formParams.Add("appid", apiInvoker.ParameterToString(Appid));
        }
      }
      if (Appkey != null){
        if(Appkey is byte[]) {
          formParams.Add("appkey", Appkey);
        } else {
          formParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
        }
      }
      if (ToolId != null){
        if(ToolId is byte[]) {
          formParams.Add("tool_id", ToolId);
        } else {
          formParams.Add("tool_id", apiInvoker.ParameterToString(ToolId));
        }
      }
      if (Url != null){
        if(Url is byte[]) {
          formParams.Add("url", Url);
        } else {
          formParams.Add("url", apiInvoker.ParameterToString(Url));
        }
      }
      

      try {
        if (typeof(List<tool>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<tool>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "POST", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<tool>) ApiInvoker.deserialize(response, typeof(List<tool>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    

    /// <summary>
    /// delete a building block tool delete a building block tool
    /// </summary>
    /// <param name="BuildingBlockId">id for the building block</param>
     /// <param name="Appid">your appid for accessing the building block</param>
     /// <param name="Appkey">your appkey for accessing the building block</param>
     /// <param name="ToolId">tool to remove from building block</param>
    
    /// <returns></returns>
    public List<tool>  GetBuildingBlockTool (string BuildingBlockId, string Appid, string Appkey, string ToolId) {
      // create path and map variables
      var path = "/buildingblocks/{building_block_id}/tools/{tool_id}".Replace("{format}","json").Replace("{" + "building_block_id" + "}", apiInvoker.ParameterToString(BuildingBlockId)).Replace("{" + "tool_id" + "}", apiInvoker.ParameterToString(ToolId));

      // query params
      var queryParams = new Dictionary<String, String>();
      var headerParams = new Dictionary<String, String>();
      var formParams = new Dictionary<String, object>();

      

      if (Appid != null){
        queryParams.Add("appid", apiInvoker.ParameterToString(Appid));
      }
      if (Appkey != null){
        queryParams.Add("appkey", apiInvoker.ParameterToString(Appkey));
      }
      

      

      

      try {
        if (typeof(List<tool>) == typeof(byte[])) {
          
          var response = apiInvoker.invokeBinaryAPI(basePath, path, "GET", queryParams, null, headerParams, formParams);
          return ((object)response) as List<tool>;
          
          
        } else {
          
          var response = apiInvoker.invokeAPI(basePath, path, "DELETE", queryParams, null, headerParams, formParams);
          if (response != null){
             return (List<tool>) ApiInvoker.deserialize(response, typeof(List<tool>));
          }
          else {
            return null;
          }
          
          
        }
      } catch (ApiException ex) {
        if(ex.ErrorCode == 404) {
          return null;
        }
        else {
          throw ex;
        }
      }
    }
    
  }
  
}
